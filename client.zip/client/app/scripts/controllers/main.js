'use strict';

/**
 * @ngdoc function
 * @name comingSoonWebsiteApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the comingSoonWebsiteApp
 */
angular.module('mainpage.snaphy')
  .controller('MainCtrl', function () {

  });

'use strict';

/**
 * @ngdoc overview
 * @name comingSoonWebsiteApp
 * @description
 * # comingSoonWebsiteApp
 *
 * Main module of the application.
 */
angular
  .module('mainpage.snaphy', [
    /*'ngAnimate',
    'ngCookies',*/
    'ngResource',
    /*'ngRoute',*/
    'ngSanitize',
    'ui.router',
    /*'ngTouch'*/
    'angular-loading-bar'
  ])

